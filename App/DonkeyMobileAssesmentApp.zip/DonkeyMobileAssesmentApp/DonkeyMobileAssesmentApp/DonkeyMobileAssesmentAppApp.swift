//
//  DonkeyMobileAssesmentAppApp.swift
//  DonkeyMobileAssesmentApp
//
//  Created by Paul Tolnor on 14/10/2025.
//

import SwiftUI

@main
struct DonkeyMobileAssesmentAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
