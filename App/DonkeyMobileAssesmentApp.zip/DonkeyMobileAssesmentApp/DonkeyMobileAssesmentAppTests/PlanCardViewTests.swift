////
////  PlanCardViewTests.swift
////  DonkeyMobileAssesmentAppTests
////
////  Created by Paul Tolnor on 14/10/2025.
////
//
//import XCTest
//import ViewInspector
//@testable import DonkeyMobileAssessmentApp
//
//final class PlanCardViewTests: XCTestCase {
//
//    func testPlanCardDisplaysTitleAndDescription() throws {
//        // Given
//        let plan = Plan(
//            title: "Walking in Faith",
//            planImageName: "post1",
//            description: "Discover how to trust God daily and walk confidently in His promises."
//        )
//        let sut = PlanCard(plan: plan)
//
//        // When
//        let titleText = try sut.inspect().find(text: plan.title).string()
//        let descriptionText = try sut.inspect().find(text: plan.description).string()
//
//        // Then
//        XCTAssertEqual(titleText, plan.title)
//        XCTAssertEqual(descriptionText, plan.description)
//    }
//
//    func testPlanCardHasImage() throws {
//        // Given
//        let plan = Plan(title: "Test Plan", planImageName: "post1", description: "Test Description")
//        let sut = PlanCard(plan: plan)
//
//        // When
//        let image = try sut.inspect().find(ViewType.Image.self)
//
//        // Then
//        XCTAssertNotNil(image)
//    }
//
//    func testPlanCardDoesNotCrashWithEmptyDescription() throws {
//        // Given
//        let plan = Plan(title: "Empty Desc", planImageName: "post1", description: "")
//        let sut = PlanCard(plan: plan)
//
//        // Then
//        XCTAssertNoThrow(try sut.inspect().find(text: plan.title))
//    }
//}
