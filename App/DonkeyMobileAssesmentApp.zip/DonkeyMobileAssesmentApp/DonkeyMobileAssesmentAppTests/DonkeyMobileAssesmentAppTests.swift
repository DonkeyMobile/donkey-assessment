//
//  DonkeyMobileAssesmentAppTests.swift
//  DonkeyMobileAssesmentAppTests
//
//  Created by Paul Tolnor on 14/10/2025.
//

import Testing
@testable import DonkeyMobileAssesmentApp

struct DonkeyMobileAssesmentAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
